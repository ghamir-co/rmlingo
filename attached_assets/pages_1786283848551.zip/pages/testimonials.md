![RM Lingo](https://rmlingo.com/wp-content/uploads/2025/06/Rm_Lingo-1.png)
Manage your privacy
To provide the best experiences, we use technologies like cookies to store and/or access device information. Consenting to these technologies will allow us to process data such as browsing behavior or unique IDs on this site. Not consenting or withdrawing consent, may adversely affect certain features and functions.
Functional   [ ]  Functional  Always active       
The technical storage or access is strictly necessary for the legitimate purpose of enabling the use of a specific service explicitly requested by the subscriber or user, or for the sole purpose of carrying out the transmission of a communication over an electronic communications network. 
Preferences  [ ]  Preferences       
The technical storage or access is necessary for the legitimate purpose of storing preferences that are not requested by the subscriber or user. 
Statistics  [ ]  Statistics       
The technical storage or access that is used exclusively for statistical purposes. The technical storage or access that is used exclusively for anonymous statistical purposes. Without a subpoena, voluntary compliance on the part of your Internet Service Provider, or additional records from a third party, information stored or retrieved for this purpose alone cannot usually be used to identify you. 
Marketing  [ ]  Marketing       
The technical storage or access is required to create user profiles to send advertising, or to track the user on a website or across several websites for similar marketing purposes. 
[Manage options](https://rmlingo.com/opt-out-preferences/#cmplz-manage-consent-container)
[Manage services](https://rmlingo.com/opt-out-preferences/#cmplz-cookies-overview)
[Manage \{vendor\_count\} vendors](https://rmlingo.com/opt-out-preferences/#cmplz-tcf-wrapper)
[Read more about these purposes](https://cookiedatabase.org/tcf/purposes/)
Accept Deny View preferences Save preferences 
[View preferences](https://rmlingo.com/opt-out-preferences/#cmplz-manage-consent-container)
[Opt\-out preferences](https://rmlingo.com/opt-out-preferences/)
[Privacy Statement](https://rmlingo.com/privacy-statement-us/)
[\{title\}](https://rmlingo.com/testimonials/#)
[![RM Lingo](https://rmlingo.com/wp-content/uploads/2025/06/Rm_Lingo.png) ](https://rmlingo.com/)
[![RM Lingo](https://rmlingo.com/wp-content/uploads/2025/06/Rm_Lingo-1.png) ](https://rmlingo.com/)
- [**\+1 619\-752\-5604](https://wa.me/16197525604) 
- [**info@rmlingo.com](mailto:info@rmlingo.com) 
[ ]  **✕ Menu 
- [Home](https://rmlingo.com/) 
- [About Us](https://rmlingo.com/about/) 
- [Services](https://rmlingo.com/testimonials/#) 
  - [Interpreting](https://rmlingo.com/interpreting/) 
  - [Translation](https://rmlingo.com/translation-services/) 
  - [Editing and proofreading](https://rmlingo.com/editing-and-proofreading/) 
  - [Localization and relocation](https://rmlingo.com/localization-and-relocation/) 
  - [Media accessibility services](https://rmlingo.com/transcription-and-subtitling-dubbing-and-voiceover/) 
  - [Consulting services and training](https://rmlingo.com/consultation/) 
  - [Technical support and equipment](https://rmlingo.com/technical-support-and-equipment/) 
- [Testimonials](https://rmlingo.com/testimonials/) 
- [Contact Us **](https://rmlingo.com/contact/) 
- [English](https://rmlingo.com/testimonials/) 
[Home](https://rmlingo.com/) Testimonials 

# Testimonials

I have been working regularly with RM Lingo for more than five years through a range of different activities and on a range of different subjects … . The services of RM Lingo have always been delivered in a very professional manner and with the utmost attention to detail and quality. The company has always been sensitive and attentive to our specific needs, and has taken all possible steps to accommodate them… . The subjects of these events have ranged from technical matters, to political issues, development, and even topics that might be considered culturally sensitive \(such as matters related to Palestinian women’s health and emotional wellbeing\). Across this range of topics, I have particularly appreciated how prepared RM Lingo staff arrive to assignments. This has ensured that the service is delivered in a very good way: in the right speed, without stuttering and with a fluent flow. I would also add that I very much value RM Lingo’s respectful treatment of difficult subjects with discretion and confidentiality.
![Testimonials](https://rmlingo.com/wp-content/uploads/2025/03/RED-CROSS-300x129.png)

##### Linda Öhman, Norwegian Red Cross, 2016
[Read full testimonial  ](https://rmlingo.com/wp-content/uploads/2025/03/Rec_NRC__RM_Lingo.pdf)

RM Lingo has on several occasions provided our various projects with high\-quality interpretation services. The interpretation services provided deal with a variety of topics including health, public finance, rule of law, governance, and other issues. Feedback received by those benefitting form the interpretation service has always been very positive.
![Testimonials](https://rmlingo.com/wp-content/uploads/2025/03/UNDP_logo.svg-1.png)

### Nadder Atta, Governance and Social Development, United Nations Development Programme, 2024
[Read full testimonial  ](https://rmlingo.com/wp-content/uploads/2025/03/UNDP_RM_Lingo_Letter_of_Recommendation.pdf)

I have had the pleasure and benefitted from Ms. Rawan Manna’s services … as both a translator of World Bank reports and other official documents and as an interpreter at several events that the Bank has organized or that I have participated in with political leaders in Palestine. Ms. Manna has been contracted by the World Bank for several years and came highly recommended to me … . She far exceeded my already high expectations. … Ms. Manna demonstrated a very high degree of professionalism, dedication and – critically – competence. The quality of her language skills and ability to simultaneously translate back and forth between English and Arabic was a contributing factor to the success of multiple World Bank events and report launches. Ms. Manna is conscientious to a fault, goes above and beyond in ensuring that her client receives the service they have paid for and that they are fully satisfied with the quality of the service… .
![Testimonials](https://rmlingo.com/wp-content/uploads/2025/03/WorldBank_Logo_optimized-17-768x348.png)

### Stefan Emblad, World Bank Group, 2023
[Read full testimonial  ](https://rmlingo.com/wp-content/uploads/2025/03/WORLD_BANK_Recommendation_2023__1_.pdf)

Ms.Manna has exemplified remarkable leadership and expertise, particularly in the recruitment, training, and mentoring of a team of seven language assistants. Ms. Manna’s role at RM Lingo required a deep understanding of language nuances and cultural sensitivities, which she managed with aplomb. Her ability to recruit and mentor her team was not just about filling positions, but rather about fostering a skilled cadre of professionals whose performance was consistently of the highest standard. Her comprehensive training programs ensured that all team members were well\-prepared for the demands of the job, equipping them with the necessary skills to handle complex language tasks effectively. … Rawan’s professional demeanor and commitment to excellence have earned her the respect and admiration of her peers and colleagues. She possesses a unique blend of leadership, technical skill, and interpersonal ability which makes her an invaluable asset in any setting requiring high\-caliber language services. She is a dynamic and driven professional, whose impact on the USSC\-ILC course has been profoundly positive.
![Testimonials](https://rmlingo.com/wp-content/uploads/2025/03/MOI_REC_LETTER_2024__1___1_.jpg)

### Major General Dr. Mohammad Jibrini, State of Palestine Ministry of Interior
[Read full testimonial  ](https://rmlingo.com/wp-content/uploads/2025/03/MOI_REC_LETTER_2024__1___1_.pdf)

I have worked overseas since 1997 in numerous countries which required me to rely on interpreters for communication. From my perspective as a frequent user of interpretation services, I can without reservation say that Ms. Manna’s interpretation is of the highest quality. She was required to translate extremely technical language and complex justice concepts using simultaneous translation which she had no difficulty in doing so, keeping good speed and accuracy. The subject matter involved sexual and gender\-based violence against women and girls and required the use of sensitive terminology. She exhibited the highest professionalism setting the important tone for the discussion of such a sensitive subject. During the workshop, Ms Manna exhibited her professionalism, skill and flexibility numerous times which greatly contributed to its success. On one day the second interpreter cancelled at the last minute. Ms. Manna continued to deliver superior quality interpretation consistently throughout the long hours while maintaining a high level of accuracy and flow. She also provided whispering translation during small group work wherein I felt I was part of the small group conversation, completely forgetting that I was not able to speak the language.

### Eileen Skinnider, International Centre for Criminal Law Reform and Criminal Justice Policy
[Read full testimonial  ](https://rmlingo.com/wp-content/uploads/2025/03/Recommendation_letter_for_Rawan_Manna.pdf)

Rawan Manna has performed simultaneous interpreting services of the language combination Arabic and English over several workshops related to financial and budget issues. She performed these services very effectively to a high level of accuracy, including providing portable receiver devices to facilitate effective one\-to\-one as well as small group communication exchanges simultaneously; using the whisper \(chuchotage\) technique while maintaining personal space and freedom to move throughout the hall all while providing clear and ‘audible interpretation’. Ms. Manna’s technique proved to be very efficient as an alternative when it’s not cost effective to rent an acoustic booth if only a few people require interpretation. Her services were also outstanding in a large group setting, where Ms. Manna was able to provide top quality simultaneous interpreting of training delivery and question sessions for a group of up to 50 people over a period of two days \(without the support of a second translator due to circumstances out of our control\) yet without sacrificing the quality. That was a testament to her high levels of energy, flexibility, professionalism and skill.
![Testimonials](https://rmlingo.com/wp-content/uploads/2025/03/Rec_Tetratech_USAID.png)

### Deanna Aubrey, Communities Thrive Project, Tetra Tech
[Read full testimonial  ](https://rmlingo.com/wp-content/uploads/2025/03/Rec_Tetratech_USAID.pdf)

In the last year I have designed and delivered both in\-person and online trainings workshops for international clients in Palestine, Jordan and Lebanon where RM Lingo were responsible for the provision of interpretation services. Their support in all instances has been exceptional; both in terms of the quality of the linguistic services provided and the professionalism with which they work … recognising the importance of not just the accuracy and quality of the interpretation provided but also the importance of creating welcoming, safe and trusting spaces for feminist learning and strategizing. … With support from RM Lingo interpreters we have delivered a series of virtual immersive learning workshops on a range of highly\-technical issues relating to different aspects of feminist economics and in ways that sought to deepen participants’ capacities for critical thinking. The quality of the interpretation provided for these interactive sessions was excellent; and enabled us to support participant’s engagement with complex ideas in ways that are uniquely difficult in virtual learning spaces. 
![Testimonials](https://rmlingo.com/wp-content/uploads/2025/03/Rec_Tetratech_USAID.png)

### Emily Brown, Feminist Consultant, UK, 2025
[Read full testimonial  ](https://rmlingo.com/wp-content/uploads/2025/06/EB-letter-of-recommendation.pdf)

## RM Lingo Professional Language Services 
![Testimonials](https://rmlingo.com/wp-content/uploads/2025/01/Logo_vertical_white.png) 

##### Newsletter

#### Subscribe to our Newsletter

##### Join our community\! Subscribe to our newsletter and stay in the loop.
Leave this field empty if you're human: 

##### RM Lingo

RM Lingo was founded in 2003 by Dr. Rawan Manna, Ph.D., a highly skilled linguist and expert in translation and interpretation.

##### Recent news
-  [The Role of Professional Translation in Global Communication](https://rmlingo.com/the-role-of-professional-translation-in-global-communication/)  
-  [How to Choose the Right Provider for Your Subtitling and Dubbing Needs](https://rmlingo.com/how-to-choose-the-right-provider-for-your-subtitling-and-dubbing-needs/)  
-  [The Benefits of Real\-Time Interpretation Services for International Businesses](https://rmlingo.com/the-benefits-of-real-time-interpretation-services-for-international-businesses/)  

##### Services
- [Translation](https://rmlingo.com/translation-services/) 
- [Editing and proofreading](https://rmlingo.com/editing-and-proofreading/) 
- [Interpreting](https://rmlingo.com/interpreting/) 
- [Consultation and training](https://rmlingo.com/consultation/) 
- [Other services](https://rmlingo.com/other-services/) 
© 2026 RM Lingo • 

**  
[](https://rmlingo.com/testimonials/)
[↑](https://rmlingo.com/testimonials/)
Manage your privacy 
This site is registered on [wpml.org](https://wpml.org/) as a development site. Switch to a production site key to [remove this banner](https://wpml.org/faq/how-to-remove-the-this-site-is-registered-on-wpml-org-as-a-development-site-notice/?utm_source=plugin&utm_medium=gui&utm_campaign=wpml-core&utm_term=footer-notice).
