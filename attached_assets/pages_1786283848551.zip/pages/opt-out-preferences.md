[![RM Lingo](https://rmlingo.com/wp-content/uploads/2025/06/Rm_Lingo.png) ](https://rmlingo.com/)
[![RM Lingo](https://rmlingo.com/wp-content/uploads/2025/06/Rm_Lingo-1.png) ](https://rmlingo.com/)
- [**\+1 619\-752\-5604](https://wa.me/16197525604) 
- [**info@rmlingo.com](mailto:info@rmlingo.com) 
[ ]  **✕ Menu 
- [Home](https://rmlingo.com/) 
- [About Us](https://rmlingo.com/about/) 
- [Services](https://rmlingo.com/opt-out-preferences/#) 
  - [Interpreting](https://rmlingo.com/interpreting/) 
  - [Translation](https://rmlingo.com/translation-services/) 
  - [Editing and proofreading](https://rmlingo.com/editing-and-proofreading/) 
  - [Localization and relocation](https://rmlingo.com/localization-and-relocation/) 
  - [Media accessibility services](https://rmlingo.com/transcription-and-subtitling-dubbing-and-voiceover/) 
  - [Consulting services and training](https://rmlingo.com/consultation/) 
  - [Technical support and equipment](https://rmlingo.com/technical-support-and-equipment/) 
- [Testimonials](https://rmlingo.com/testimonials/) 
- [Contact Us **](https://rmlingo.com/contact/) 
- [English](https://rmlingo.com/opt-out-preferences/) 
[Home](https://rmlingo.com/) Opt\-out preferences 

# Opt\-out preferences

*This page was last changed on June 14, 2025, last checked on June 14, 2025 and applies to citizens and legal permanent residents of the United States. *

## 1. Introduction

Our website, [https://rmlingo.com](https://rmlingo.com/) \(hereinafter: "the website"\) uses cookies and other related technologies \(for convenience all technologies are referred to as "cookies"\). Cookies are also placed by third parties we have engaged. In the document below we inform you about the use of cookies on our website.

## 2. Cookies

When you visit our website it can be necessary to store and/or read certain data from your device by using technologies such as cookies.

2.1 Technical or functional cookies

Some cookies ensure that certain parts of the website work properly and that your user preferences remain known. By placing functional cookies, we make it easier for you to visit our website. This way, you do not need to repeatedly enter the same information when visiting our website and, for example, the items remain in your shopping cart until you have paid. We may place these cookies without your consent.

2.2 Statistics cookies

We use statistics cookies to optimize the website experience for our users. With these statistics cookies we get insights in the usage of our website.

2.3 Marketing/Tracking cookies

Marketing/Tracking cookies are cookies or any other form of local storage, used to create user profiles to display advertising or to track the user on this website or across several websites for similar marketing purposes.

2.4 Social media

On our website, we have included content from Facebook, Twitter and LinkedIn to promote web pages \(e.g. “like”, “pin”\) or share \(e.g. “tweet”\) on social networks like Facebook, Twitter and LinkedIn. This content is embedded with code derived from Facebook, Twitter and LinkedIn and places cookies. This content might store and process certain information for personalized advertising.

Please read the privacy statement of these social networks \(which can change regularly\) to read what they do with your \(personal\) data which they process using these cookies. The data that is retrieved is anonymized as much as possible. Facebook, Twitter and LinkedIn are located in the United States.

## 3. Placed cookies


Most of these technologies have a function, a purpose, and an expiration period.
1. A function is a particular task a technology has. So a function can be to "store certain data." 
2. Purpose is "the Why" behind the function. Maybe the data is stored because it is needed for statistics. 
3. The expiration period shows the length of the period the used technology can “store or read certain data." 


### WordPress

Functional
Consent to service wordpress [ ] 

#### Usage

We use WordPress for website development. [Read more](https://cookiedatabase.org/service/wordpress/)

#### Sharing data

This data is not shared with third parties.

#### Functional

##### Name
[wpEmojiSettingsSupports](https://cookiedatabase.org/cookie/wordpress/wpemojisettingssupports/)

##### Expiration
session

##### Function
Store browser details

##### Name
[wp\-settings\-\*](https://cookiedatabase.org/cookie/wordpress/wp-settings/)

##### Expiration
persistent

##### Function
Store user preferences

##### Name
[wp\-settings\-time\-\*](https://cookiedatabase.org/cookie/wordpress/wp-settings-time/)

##### Expiration
1 year

##### Function
Store user preferences

##### Name
[wordpress\_test\_cookie](https://cookiedatabase.org/cookie/wordpress/wordpress_test_cookie/)

##### Expiration
session

##### Function
Read if cookies can be placed

##### Name
[wordpress\_logged\_in\_\*](https://cookiedatabase.org/cookie/wordpress/wordpress_logged_in_/)

##### Expiration
persistent

##### Function
Store logged in users

### Go Daddy

Statistics
Consent to service go\-daddy [ ] 

#### Usage

We use Go Daddy for website hosting. [Read more](https://cookiedatabase.org/service/go-daddy/)

#### Sharing data


#### Statistics

##### Name
[\_tccl\_visitor](https://cookiedatabase.org/cookie/go-daddy/_tccl_visitor/)

##### Expiration
1 year

##### Function
Store anonymized statistics

### WPML

Functional
Consent to service wpml [ ] 

#### Usage

We use WPML for locale management. [Read more](https://cookiedatabase.org/service/wpml/)

#### Sharing data

This data is not shared with third parties.

#### Functional

##### Name
[wp\-wpml\_current\_language](https://cookiedatabase.org/cookie/wpml/wp-wpml_current_language/)

##### Expiration
1 day

##### Function
Store language settings

### Google Fonts

Marketing
Consent to service google\-fonts [ ] 

#### Usage

We use Google Fonts for display of webfonts. [Read more](https://cookiedatabase.org/service/google-fonts/)

#### Sharing data

For more information, please read the [Google Fonts Privacy Statement](https://policies.google.com/privacy).

#### Marketing

##### Name
[Google Fonts API](https://cookiedatabase.org/cookie/google-fonts/tcb_google_fonts/)

##### Expiration
expires immediately

##### Function
Read user IP address

### Google reCAPTCHA

Marketing
Consent to service google\-recaptcha [ ] 

#### Usage

We use Google reCAPTCHA for spam prevention. [Read more](https://cookiedatabase.org/service/google-recaptcha/)

#### Sharing data

For more information, please read the [Google reCAPTCHA Privacy Statement](https://policies.google.com/privacy).

#### Marketing

##### Name
[rc::c](https://cookiedatabase.org/cookie/google-recaptcha/rcc/)

##### Expiration
session

##### Function
Read and filter requests from bots

##### Name
[rc::b](https://cookiedatabase.org/cookie/google-recaptcha/rcb/)

##### Expiration
session

##### Function
Read and filter requests from bots

##### Name
[rc::a](https://cookiedatabase.org/cookie/google-recaptcha/rca/)

##### Expiration
persistent

##### Function
Read and filter requests from bots

### Google Maps

Marketing
Consent to service google\-maps [ ] 

#### Usage

We use Google Maps for maps display. [Read more](https://cookiedatabase.org/service/google-maps/)

#### Sharing data

For more information, please read the [Google Maps Privacy Statement](https://business.safety.google/privacy/).

#### Marketing

##### Name
[Google Maps API](https://cookiedatabase.org/cookie/google-maps/google-maps-api/)

##### Expiration
expires immediately

##### Function
Read user IP address

### Facebook

Marketing, Functional
Consent to service facebook [ ] 

#### Usage

We use Facebook for display of recent social posts and/or social share buttons. [Read more](https://cookiedatabase.org/service/facebook/)

#### Sharing data

For more information, please read the [Facebook Privacy Statement](https://www.facebook.com/policy/cookies).

#### Marketing

##### Name
[\_fbc](https://cookiedatabase.org/cookie/facebook/_fbc/)

##### Expiration
2 years

##### Function
Store last visit

##### Name
[fbm\*](https://cookiedatabase.org/cookie/facebook/fbm_/)

##### Expiration
1 year

##### Function
Store account details

##### Name
[xs](https://cookiedatabase.org/cookie/facebook/xs/)

##### Expiration
3 months

##### Function
Store a unique session ID

##### Name
[fr](https://cookiedatabase.org/cookie/facebook/fr/)

##### Expiration
3 months

##### Function
Provide ad delivery or retargeting

##### Name
[act](https://cookiedatabase.org/cookie/facebook/act/)

##### Expiration
90 days

##### Function
Store logged in users

##### Name
[\_fbp](https://cookiedatabase.org/cookie/facebook/_fbp/)

##### Expiration
3 months

##### Function
Store and track visits across websites

##### Name
[datr](https://cookiedatabase.org/cookie/facebook/datr/)

##### Expiration
2 years

##### Function
Provide fraud prevention

##### Name
[c\_user](https://cookiedatabase.org/cookie/facebook/c_user/)

##### Expiration
30 days

##### Function
Store a unique user ID

##### Name
[sb](https://cookiedatabase.org/cookie/facebook/sb/)

##### Expiration
2 years

##### Function
Store browser details

##### Name
[\*\_fbm\_](https://cookiedatabase.org/cookie/facebook/_fbm_/)

##### Expiration
1 year

##### Function
Store account details

#### Functional

##### Name
[wd](https://cookiedatabase.org/cookie/facebook/wd/)

##### Expiration
1 week

##### Function
Read screen resolution

##### Name
[csm](https://cookiedatabase.org/cookie/facebook/csm/)

##### Expiration
90 days

##### Function
Provide fraud prevention

##### Name
[actppresence](https://cookiedatabase.org/cookie/facebook/actppresence/)

##### Expiration
session

##### Function
Store and track if the browser tab is active

### Twitter

Functional, Marketing
Consent to service twitter [ ] 

#### Usage

We use Twitter for display of recent social posts and/or social share buttons. [Read more](https://cookiedatabase.org/service/twitter/)

#### Sharing data

For more information, please read the [Twitter Privacy Statement](https://twitter.com/en/privacy).

#### Functional

##### Name
[local\_storage\_support\_test](https://cookiedatabase.org/cookie/twitter/local_storage_support_test/)

##### Expiration
persistent

##### Function
Provide load balancing functionality

#### Marketing

##### Name
[metrics\_token](https://cookiedatabase.org/cookie/twitter/metrics_token/)

##### Expiration
persistent

##### Function
Store if the user has seen embedded content

### LinkedIn

Functional, Marketing, Statistics, Preferences
Consent to service linkedin [ ] 

#### Usage

We use LinkedIn for display of recent social posts and/or social share buttons. [Read more](https://cookiedatabase.org/service/linkedin/)

#### Sharing data

For more information, please read the [LinkedIn Privacy Statement](https://www.linkedin.com/legal/privacy-policy).

#### Functional

##### Name
[sdsc](https://cookiedatabase.org/cookie/linkedin/auto-draft-20/)

##### Expiration
session

##### Function
Provide load balancing functionality

##### Name
[li\_gc](https://cookiedatabase.org/cookie/linkedin/auto-draft-16/)

##### Expiration
6 months

##### Function
Store cookie consent preferences

##### Name
[BizographicsOptOut](https://cookiedatabase.org/cookie/linkedin/bizographicsoptout/)

##### Expiration
10 years

##### Function
Store privacy preferences

#### Marketing

##### Name
[lms\_ads](https://cookiedatabase.org/cookie/linkedin/auto-draft-19/)

##### Expiration
30 days

##### Function
Store and track visits across websites

##### Name
[\_guid](https://cookiedatabase.org/cookie/linkedin/_guid/)

##### Expiration
90 days

##### Function
Store and track a visitor's identity

##### Name
[li\-oatml](https://cookiedatabase.org/cookie/linkedin/li-oatml/)

##### Expiration
1 month

##### Function
Provide ad delivery or retargeting

##### Name
[li\_sugr](https://cookiedatabase.org/cookie/linkedin/li_sugr/)

##### Expiration
90 days

##### Function
Store and track a visitor's identity

##### Name
[UserMatchHistory](https://cookiedatabase.org/cookie/linkedin/usermatchhistory/)

##### Expiration
30 days

##### Function
Provide ad delivery or retargeting

#### Statistics

##### Name
[lms\_analytics](https://cookiedatabase.org/cookie/linkedin/auto-draft-18/)

##### Expiration
30 days

##### Function
Store and track a visitor's identity

##### Name
[AnalyticsSyncHistory](https://cookiedatabase.org/cookie/linkedin/analyticssynchistory/)

##### Expiration
30 days

##### Function
Store and track visits across websites

#### Preferences

##### Name
[li\_alerts](https://cookiedatabase.org/cookie/linkedin/li_alerts/)

##### Expiration
1 year

##### Function
Store if a message has been shown

##### Name
[bcookie](https://cookiedatabase.org/cookie/linkedin/bcookie-2/)

##### Expiration
1 year

##### Function
Store browser details

##### Name
[lidc](https://cookiedatabase.org/cookie/linkedin/lidc/)

##### Expiration
1 day

##### Function
Provide load balancing functionality

##### Name
[bscookie](https://cookiedatabase.org/cookie/linkedin/bscookie/)

##### Expiration
1 year

##### Function
Store logged in users

### Complianz

Functional
Consent to service complianz [ ] 

#### Usage

We use Complianz for cookie consent management. [Read more](https://cookiedatabase.org/service/complianz/)

#### Sharing data

This data is not shared with third parties. For more information, please read the [Complianz Privacy Statement](https://complianz.io/legal/privacy-statement/).

#### Functional

##### Name
[cmplz\_functional](https://cookiedatabase.org/cookie/complianz/cmplz_functional/)

##### Expiration
365 days

##### Function
Store cookie consent preferences

##### Name
[cmplz\_statistics](https://cookiedatabase.org/cookie/complianz/cmplz_statistics/)

##### Expiration
365 days

##### Function
Store cookie consent preferences

##### Name
[cmplz\_preferences](https://cookiedatabase.org/cookie/complianz/cmplz_preferences/)

##### Expiration
365 days

##### Function
Store cookie consent preferences

##### Name
[cmplz\_marketing](https://cookiedatabase.org/cookie/complianz/cmplz_marketing/)

##### Expiration
365 days

##### Function
Store cookie consent preferences

### Miscellaneous

Purpose pending investigation
Consent to service miscellaneous [ ] 

#### Usage


#### Sharing data

Sharing of data is pending investigation

#### Purpose pending investigation

##### Name
ate\-maiya\-info\_37363361\-3033\-5336\-b966\-353265313339

##### Expiration

##### Function

##### Name
dps\_site\_id

##### Expiration

##### Function

##### Name
wp\_lang

##### Expiration

##### Function

## 4. Browser and Device based Consent

When you visit our website for the first time, we will show you a pop\-up with an explanation about cookies. You do have the right to opt\-out and to object against the further use of non\-functional cookies.

4.1 Manage your opt\-out preferences
You have loaded the Cookie Policy without javascript support. On AMP, you can use the manage consent button on the bottom of the page.
Functional   [ ]  Functional  Always active       
The technical storage or access is strictly necessary for the legitimate purpose of enabling the use of a specific service explicitly requested by the subscriber or user, or for the sole purpose of carrying out the transmission of a communication over an electronic communications network. 
Preferences  [ ]  Preferences       
The technical storage or access is necessary for the legitimate purpose of storing preferences that are not requested by the subscriber or user. 
Statistics  [ ]  Statistics       
The technical storage or access that is used exclusively for statistical purposes. The technical storage or access that is used exclusively for anonymous statistical purposes. Without a subpoena, voluntary compliance on the part of your Internet Service Provider, or additional records from a third party, information stored or retrieved for this purpose alone cannot usually be used to identify you. 
Marketing  [ ]  Marketing       
The technical storage or access is required to create user profiles to send advertising, or to track the user on a website or across several websites for similar marketing purposes. 

## 5. Enabling/disabling and deleting cookies

You can use your internet browser to automatically or manually delete cookies. You can also specify that certain cookies may not be placed. Another option is to change the settings of your internet browser so that you receive a message each time a cookie is placed. For more information about these options, please refer to the instructions in the Help section of your browser.

Please note that our website may not work properly if all cookies are disabled. If you do delete the cookies in your browser, they will be placed again after your consent when you visit our website again.

## 6. Your rights with respect to personal data

You have the following rights with respect to your personal data:
- you may submit a request for access to the data we process about you; 
- you may object to the processing; 
- you may request an overview, in a commonly used format, of the data we process about you; 
- you may request correction or deletion of the data if it is incorrect or not or no longer relevant, or to ask to restrict the processing of the data. 

To exercise these rights, please contact us. Please refer to the contact details at the bottom of this Cookie Policy. If you have a complaint about how we handle your data, we would like to hear from you.

For more information about your rights with respect to personal data, please refer to our [Privacy Statement](https://rmlingo.com/privacy-statement-us/)

## 7. Contact details

For questions and/or comments about our Cookie Policy and this statement, please contact us by using the following contact details:

RM Lingo
United States and Middle East
United States
Website: [https://rmlingo.com](https://rmlingo.com/)
Email: info@ex.comrmlingo.com
Phone number: \+972 595 555 0535

This Cookie Policy was synchronized with [cookiedatabase.org](https://cookiedatabase.org/) on July 31, 2026.

## RM Lingo Professional Language Services 
![Opt\-out preferences](https://rmlingo.com/wp-content/uploads/2025/01/Logo_vertical_white.png) 

##### Newsletter

#### Subscribe to our Newsletter

##### Join our community\! Subscribe to our newsletter and stay in the loop.
Leave this field empty if you're human: 

##### RM Lingo

RM Lingo was founded in 2003 by Dr. Rawan Manna, Ph.D., a highly skilled linguist and expert in translation and interpretation.

##### Recent news
-  [The Role of Professional Translation in Global Communication](https://rmlingo.com/the-role-of-professional-translation-in-global-communication/)  
-  [How to Choose the Right Provider for Your Subtitling and Dubbing Needs](https://rmlingo.com/how-to-choose-the-right-provider-for-your-subtitling-and-dubbing-needs/)  
-  [The Benefits of Real\-Time Interpretation Services for International Businesses](https://rmlingo.com/the-benefits-of-real-time-interpretation-services-for-international-businesses/)  

##### Services
- [Translation](https://rmlingo.com/translation-services/) 
- [Editing and proofreading](https://rmlingo.com/editing-and-proofreading/) 
- [Interpreting](https://rmlingo.com/interpreting/) 
- [Consultation and training](https://rmlingo.com/consultation/) 
- [Other services](https://rmlingo.com/other-services/) 
© 2026 RM Lingo • 

**  
[](https://rmlingo.com/opt-out-preferences/)
[↑](https://rmlingo.com/opt-out-preferences/)
This site is registered on [wpml.org](https://wpml.org/) as a development site. Switch to a production site key to [remove this banner](https://wpml.org/faq/how-to-remove-the-this-site-is-registered-on-wpml-org-as-a-development-site-notice/?utm_source=plugin&utm_medium=gui&utm_campaign=wpml-core&utm_term=footer-notice).
