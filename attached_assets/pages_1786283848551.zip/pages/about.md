![RM Lingo](https://rmlingo.com/wp-content/uploads/2025/06/Rm_Lingo-1.png)
Manage your privacy
To provide the best experiences, we use technologies like cookies to store and/or access device information. Consenting to these technologies will allow us to process data such as browsing behavior or unique IDs on this site. Not consenting or withdrawing consent, may adversely affect certain features and functions.
Functional   [ ]  Functional  Always active       
The technical storage or access is strictly necessary for the legitimate purpose of enabling the use of a specific service explicitly requested by the subscriber or user, or for the sole purpose of carrying out the transmission of a communication over an electronic communications network. 
Preferences  [ ]  Preferences       
The technical storage or access is necessary for the legitimate purpose of storing preferences that are not requested by the subscriber or user. 
Statistics  [ ]  Statistics       
The technical storage or access that is used exclusively for statistical purposes. The technical storage or access that is used exclusively for anonymous statistical purposes. Without a subpoena, voluntary compliance on the part of your Internet Service Provider, or additional records from a third party, information stored or retrieved for this purpose alone cannot usually be used to identify you. 
Marketing  [ ]  Marketing       
The technical storage or access is required to create user profiles to send advertising, or to track the user on a website or across several websites for similar marketing purposes. 
[Manage options](https://rmlingo.com/opt-out-preferences/#cmplz-manage-consent-container)
[Manage services](https://rmlingo.com/opt-out-preferences/#cmplz-cookies-overview)
[Manage \{vendor\_count\} vendors](https://rmlingo.com/opt-out-preferences/#cmplz-tcf-wrapper)
[Read more about these purposes](https://cookiedatabase.org/tcf/purposes/)
Accept Deny View preferences Save preferences 
[View preferences](https://rmlingo.com/opt-out-preferences/#cmplz-manage-consent-container)
[Opt\-out preferences](https://rmlingo.com/opt-out-preferences/)
[Privacy Statement](https://rmlingo.com/privacy-statement-us/)
[\{title\}](https://rmlingo.com/about/#)
[![RM Lingo](https://rmlingo.com/wp-content/uploads/2025/06/Rm_Lingo.png) ](https://rmlingo.com/)
[![RM Lingo](https://rmlingo.com/wp-content/uploads/2025/06/Rm_Lingo-1.png) ](https://rmlingo.com/)
- [**\+1 619\-752\-5604](https://wa.me/16197525604) 
- [**info@rmlingo.com](mailto:info@rmlingo.com) 
[ ]  **✕ Menu 
- [Home](https://rmlingo.com/) 
- [About Us](https://rmlingo.com/about/) 
- [Services](https://rmlingo.com/about/#) 
  - [Interpreting](https://rmlingo.com/interpreting/) 
  - [Translation](https://rmlingo.com/translation-services/) 
  - [Editing and proofreading](https://rmlingo.com/editing-and-proofreading/) 
  - [Localization and relocation](https://rmlingo.com/localization-and-relocation/) 
  - [Media accessibility services](https://rmlingo.com/transcription-and-subtitling-dubbing-and-voiceover/) 
  - [Consulting services and training](https://rmlingo.com/consultation/) 
  - [Technical support and equipment](https://rmlingo.com/technical-support-and-equipment/) 
- [Testimonials](https://rmlingo.com/testimonials/) 
- [Contact Us **](https://rmlingo.com/contact/) 
- [English](https://rmlingo.com/about/) 
[Home](https://rmlingo.com/) About Us 

# About Us

## Our history

RM Lingo was founded in 2003 in the United States by Dr Rawan Manna, an expert interpreter and translator.  Based on the growing demand for RM Lingo’s services, in 2007 Rawan relocated RM Lingo’s operations to the Middle East, where it began to attract multi\-national clients. Providing services to international clients across a wide range of countries enabled RM Lingo to build a growing network with other language experts locally and around the world. 

To meet the high demand for services regionally and internationally, RM Lingo developed an agile and flexible model: a core team of seasoned language experts augmented with language experts hand\-picked from its global network, exponentially expanding the range of languages and locations that RM Lingo could serve and ensuring consistent quality across all assignments. This robust model has enabled to RM Lingo to meet the needs of high\-level clients in locations around on the world on a wide range of projects.

Over the past 22 years, RM Lingo has earned a reputation for exceptional language services provided with excellence and flexibility.
**[See testimonials from our clients.](https://rmlingo.com/testimonials/) **

## Our mission 

Our mission is to enable powerful, precise, and seamless communication
between individuals or organizations from different linguistic and cultural contexts.

## Our team 

RM Lingo uses a dynamic and agile model. Our core team is a carefully curated group of elite freelance language experts who have been selected on the basis of their formal qualifications, years of experience, cultural fluency, and subject\-matter expertise. Our interpreters are selected based on proven performance in high\-stakes settings—including diplomatic, legal, security, and humanitarian contexts.

In addition to our core team, we work with an extensive network of language experts around the world. These strategic partnerships continue to develop as we work with language experts from other countries on projects for international clients. These are experts we have seen in action. This enables us to hand\-pick language experts across a very wide range of languages and locations to match the source and target language requirements, subject specializations, and other aspects of your project, and deploy an agile team to meet the specific needs of each project. 

*RM Lingo is proud to have been founded by a woman – the company’s owner and CEO – and to work with a core team of women who are seasoned language experts and have made substantial contributions across their diverse fields of specialization.*
![About Us](https://rmlingo.com/wp-content/uploads/2025/06/Rania-2.jpg) 

**Dr. Rania Filfil**  is one of our key strategic partners. With a master’s degree in Applied Foreign Languages \(Université Lumière, France\), a doctorate in Foreign Languages and Civilizations \(Universite de Paris\), and over 30 years of experience working with international organizations, Rania brings an extremely strong suite of expertise to the partnership. She is an expert interpreter and translator in Arabic, English, and French, with strong knowledge of several other languages. She has interpreted for numerous heads of state and high\-level international fora and has translated dozens of published works and hundreds of high\-level documents for governments and international institutions. Rania contributed a chapter to a published book and has written several articles for a weekly magazine. She also trains interpreters and translators for government departments and sits on a government committee for textbook revision. 

## Our ethos 
-  
**WE VALUE QUALITY AND ARE COMMITTED TO EXCELLENCE.** This means understanding our clients’ needs deeply, meeting their specifications accurately, delivering services with technical precision and expert insight, and adding more value where we find opportunities. 
-  
**WE UPHOLD OUR OWN PROFFESIONALISM AND YOURS**. As professionals, we ensure that we maintain – and exceed – professional standards in the delivery of our services and products and in our conduct with our clients and their participants and. But we understand that it’s not enough to only uphold the professional code of our own sector – we need to also understand and observe the professional code of your profession as we engage with your events, participants, or important documents and artefacts. 
-  
**WE ARE COMMITTED TO AUTHENTICITY**. We want to enable the unique voices and original ideas of those we work with to be heard with their true intent and without losing the heart or nuance of their message. We pledge to be authentic in our interactions with our clients and those who take part in their activities. 
-  
**WE HONOUR CONFIDENTIALITY**. We handle sensitive materials and topics with respect. We deeply respect the unique and complex experiences of participants in events or research. 
-  
**WE CENTRE WOMEN**. RM Lingo’s founder and core team of language experts are women who are leaders in this industry and in their respective fields of expertise. We are proudly feminist. We advocate for the empowerment of women in the professional and public spheres. 
-  
**WE APPRECIATE CONTEXT**. Situated in the MENA region with strong background and experience in the West, we have a deep understanding of diverse cultural perspectives and worldviews. This grounds the way we work with clients and craft messages for audiences from different linguistic and cultural backgrounds. We seek to engage with insight and emotional intelligence and faithfully represent the intent and unique voice of individuals from every background. 
-  
**WE GIVE BACK**. We have provided services pro bono on many occasions. This has included providing free training and English classes, as well as offering our standard services at no charge to clients whose mission we would like to support. 
**WE VALUE QUALITY AND ARE COMMITTED TO EXCELLENCE.** This means understanding our clients’ needs deeply, meeting their specifications accurately, delivering services with technical precision and expert insight, and adding more value where we find opportunities.
 
**WE UPHOLD OUR OWN PROFFESIONALISM AND YOURS**. As professionals, we ensure that we maintain – and exceed – professional standards in the delivery of our services and products and in our conduct with our clients and their participants and. But we understand that it’s not enough to only uphold the professional code of our own sector – we need to also understand and observe the professional code of your profession as we engage with your events, participants, or important documents and artefacts.
 
**WE ARE COMMITTED TO AUTHENTICITY**. We want to enable the unique voices and original ideas of those we work with to be heard with their true intent and without losing the heart or nuance of their message. We pledge to be authentic in our interactions with our clients and those who take part in their activities.
 
**WE HONOUR CONFIDENTIALITY**. We handle sensitive materials and topics with respect. We deeply respect the unique and complex experiences of participants in events or research.
 
**WE CENTRE WOMEN**. RM Lingo’s founder and core team of language experts are women who are leaders in this industry and in their respective fields of expertise. We are proudly feminist. We advocate for the empowerment of women in the professional and public spheres.
 
**WE APPRECIATE CONTEXT**. Situated in the MENA region with strong background and experience in the West, we have a deep understanding of diverse cultural perspectives and worldviews. This grounds the way we work with clients and craft messages for audiences from different linguistic and cultural backgrounds. We seek to engage with insight and emotional intelligence and faithfully represent the intent and unique voice of individuals from every background.
 
**WE GIVE BACK**. We have provided services pro bono on many occasions. This has included providing free training and English classes, as well as offering our standard services at no charge to clients whose mission we would like to support.

## Our AI policy 

AI tools lack the nuance and insight required for handling sensitive communications and materials that impact human lives.

We guarantee that all our services are delivered by human experts with advanced

qualifications and significant experience in their field.

## What our clients have to say about our ethos 

“Ms. Manna’s role at RM Lingo required a deep understanding of language nuances and cultural sensitivities, which she managed with aplomb.”

##### *Major General Dr. Mohammad Jibrini, Ministry of Interior, State of Palestine, 2024*

“The subject matter involved sexual and gender\-based violence against women and girls and required the use of sensitive terminology. She exhibited the highest professionalism setting the important tone for the discussion of such a sensitive subject.”

##### *Eileen Skinnider, International Centre for Criminal Law Reform and Criminal Justice Policy \(Canada\)
*

“The services of RM Lingo have always been delivered in a very professional manner and with the utmost attention to detail and quality. The company has always been sensitive and attentive to our specific needs, and has taken all possible steps to accommodate them…. I have particularly appreciated how prepared RM Lingo staff arrive to assignments. This has ensured that the service is delivered in a very good way: in the right speed, without stuttering and with a fluent flow… . I very much value RM Lingo’s respectful treatment of difficult subjects with discretion and confidentiality.”

##### *Linda Öhman, Norwegian Red Cross
*

“Ms. Manna is conscientious to a fault, goes above and beyond in ensuring that her client receives the service they have paid for and that they are fully satisfied with the quality of the service or produce she and her employees/contractors provide. She has exceptional organizational and negotiation skills and her attention to detail is also impressive. Ultimately, what will remain with me most is her ability to always put her clients’ interests first and how she will be relentless in ensuring that those interests are met while always seeking to find win\-win solutions for any counterparts and her clients.”

##### *Stefan Emblad, World Bank Group*

“Ms. Manna is an excellent interpreter, a reliable professional with an extremely high level of skills. In addition, she is a lovey and kind person who shares her experiences and information about the local context in an open and friendly manner.”

##### *Eileen Skinnider, International Centre for Criminal Law Reform and Criminal Justice Policy \(Canada\)
*

## RM Lingo Professional Language Services 
![About Us](https://rmlingo.com/wp-content/uploads/2025/01/Logo_vertical_white.png) 

##### Newsletter

#### Subscribe to our Newsletter

##### Join our community\! Subscribe to our newsletter and stay in the loop.
Leave this field empty if you're human: 

##### RM Lingo

RM Lingo was founded in 2003 by Dr. Rawan Manna, Ph.D., a highly skilled linguist and expert in translation and interpretation.

##### Recent news
-  [The Role of Professional Translation in Global Communication](https://rmlingo.com/the-role-of-professional-translation-in-global-communication/)  
-  [How to Choose the Right Provider for Your Subtitling and Dubbing Needs](https://rmlingo.com/how-to-choose-the-right-provider-for-your-subtitling-and-dubbing-needs/)  
-  [The Benefits of Real\-Time Interpretation Services for International Businesses](https://rmlingo.com/the-benefits-of-real-time-interpretation-services-for-international-businesses/)  

##### Services
- [Translation](https://rmlingo.com/translation-services/) 
- [Editing and proofreading](https://rmlingo.com/editing-and-proofreading/) 
- [Interpreting](https://rmlingo.com/interpreting/) 
- [Consultation and training](https://rmlingo.com/consultation/) 
- [Other services](https://rmlingo.com/other-services/) 
© 2026 RM Lingo • 

**  
[](https://rmlingo.com/about/)
[↑](https://rmlingo.com/about/)
Manage your privacy 
This site is registered on [wpml.org](https://wpml.org/) as a development site. Switch to a production site key to [remove this banner](https://wpml.org/faq/how-to-remove-the-this-site-is-registered-on-wpml-org-as-a-development-site-notice/?utm_source=plugin&utm_medium=gui&utm_campaign=wpml-core&utm_term=footer-notice).
