![RM Lingo](https://rmlingo.com/wp-content/uploads/2025/06/Rm_Lingo-1.png)
Manage your privacy
To provide the best experiences, we use technologies like cookies to store and/or access device information. Consenting to these technologies will allow us to process data such as browsing behavior or unique IDs on this site. Not consenting or withdrawing consent, may adversely affect certain features and functions.
Functional   [ ]  Functional  Always active       
The technical storage or access is strictly necessary for the legitimate purpose of enabling the use of a specific service explicitly requested by the subscriber or user, or for the sole purpose of carrying out the transmission of a communication over an electronic communications network. 
Preferences  [ ]  Preferences       
The technical storage or access is necessary for the legitimate purpose of storing preferences that are not requested by the subscriber or user. 
Statistics  [ ]  Statistics       
The technical storage or access that is used exclusively for statistical purposes. The technical storage or access that is used exclusively for anonymous statistical purposes. Without a subpoena, voluntary compliance on the part of your Internet Service Provider, or additional records from a third party, information stored or retrieved for this purpose alone cannot usually be used to identify you. 
Marketing  [ ]  Marketing       
The technical storage or access is required to create user profiles to send advertising, or to track the user on a website or across several websites for similar marketing purposes. 
[Manage options](https://rmlingo.com/opt-out-preferences/#cmplz-manage-consent-container)
[Manage services](https://rmlingo.com/opt-out-preferences/#cmplz-cookies-overview)
[Manage \{vendor\_count\} vendors](https://rmlingo.com/opt-out-preferences/#cmplz-tcf-wrapper)
[Read more about these purposes](https://cookiedatabase.org/tcf/purposes/)
Accept Deny View preferences Save preferences 
[View preferences](https://rmlingo.com/opt-out-preferences/#cmplz-manage-consent-container)
[Opt\-out preferences](https://rmlingo.com/opt-out-preferences/)
[Privacy Statement](https://rmlingo.com/privacy-statement-us/)
[\{title\}](https://rmlingo.com/privacy-statement-us/#)
[![RM Lingo](https://rmlingo.com/wp-content/uploads/2025/06/Rm_Lingo.png) ](https://rmlingo.com/)
[![RM Lingo](https://rmlingo.com/wp-content/uploads/2025/06/Rm_Lingo-1.png) ](https://rmlingo.com/)
- [**\+1 619\-752\-5604](https://wa.me/16197525604) 
- [**info@rmlingo.com](mailto:info@rmlingo.com) 
[ ]  **✕ Menu 
- [Home](https://rmlingo.com/) 
- [About Us](https://rmlingo.com/about/) 
- [Services](https://rmlingo.com/privacy-statement-us/#) 
  - [Interpreting](https://rmlingo.com/interpreting/) 
  - [Translation](https://rmlingo.com/translation-services/) 
  - [Editing and proofreading](https://rmlingo.com/editing-and-proofreading/) 
  - [Localization and relocation](https://rmlingo.com/localization-and-relocation/) 
  - [Media accessibility services](https://rmlingo.com/transcription-and-subtitling-dubbing-and-voiceover/) 
  - [Consulting services and training](https://rmlingo.com/consultation/) 
  - [Technical support and equipment](https://rmlingo.com/technical-support-and-equipment/) 
- [Testimonials](https://rmlingo.com/testimonials/) 
- [Contact Us **](https://rmlingo.com/contact/) 
- [English](https://rmlingo.com/privacy-statement-us/) 
[Home](https://rmlingo.com/) Privacy Statement 

# Privacy Statement

*This privacy statement was last changed on June 14, 2025, last checked on June 14, 2025, and applies to citizens and legal permanent residents of the United States.*


In this privacy statement, we explain what we do with the data we obtain about you via [https://rmlingo.com](https://rmlingo.com/). We recommend you carefully read this statement. In our processing we comply with the requirements of privacy legislation. That means, among other things, that:
- we clearly state the purposes for which we process personal data. We do this by means of this privacy statement; 
- we aim to limit our collection of personal data to only the personal data required for legitimate purposes; 
- we first request your explicit consent to process your personal data in cases requiring your consent; 
- we take appropriate security measures to protect your personal data and also require this from parties that process personal data on our behalf; 
- we respect your right to access your personal data or have it corrected or deleted, at your request. 


If you have any questions, or want to know exactly what data we keep of you, please contact us.

## 1. Sharing with other parties

We only share or disclose this data to other recipients for the following purposes:

## 2. Disclosure practices


We disclose personal information if we are required by law or by a court order, in response to a law enforcement agency, to the extent permitted under other provisions of law, to provide information, or for an investigation on a matter related to public safety.

If our website or organisation is taken over, sold, or involved in a merger or acquisition, your details may be disclosed to our advisers and any prospective purchasers and will be passed on to the new owners.


## 3. How we respond to Do Not Track signals & Global Privacy Control 

Our website does not respond to and does not support the Do Not Track \(DNT\) header request field.

## 4. Cookies

Our website uses cookies. For more information about cookies, please refer to our Cookie Policy on our [Opt\-out preferences](https://rmlingo.com/opt-out-preferences/) webpage. 

We have concluded a data processing agreement with Google.

Google may not use the data for any other Google services.

The inclusion of full IP addresses is blocked by us.

## 5. Security

We are committed to the security of personal data. We take appropriate security measures to limit abuse of and unauthorized access to personal data. This ensures that only the necessary persons have access to your data, that access to the data is protected, and that our security measures are regularly reviewed.

## 6. Third\-party websites

This privacy statement does not apply to third\-party websites connected by links on our website. We cannot guarantee that these third parties handle your personal data in a reliable or secure manner. We recommend you read the privacy statements of these websites prior to making use of these websites.

## 7. Amendments to this privacy statement

We reserve the right to make amendments to this privacy statement. It is recommended that you consult this privacy statement regularly in order to be aware of any changes. In addition, we will actively inform you wherever possible.

## 8. Accessing and modifying your data

If you have any questions or want to know which personal data we have about you, please contact us. Please make sure to always clearly state who you are, so that we can be certain that we do not modify or delete any data of the wrong person. We shall provide the requested information only upon receipt of a verifiable consumer request. You can contact us by using the information below. You have the following rights:

8.1 You have the following rights with respect to your personal data
1. You may submit a request for access to the data we process about you. 
2. You may object to the processing. 
3. You may request an overview, in a commonly used format, of the data we process about you. 
4. You may request correction or deletion of the data if it is incorrect or not or no longer relevant, or to ask to restrict the processing of the data. 
5. You may appeal our decision whenever we refuse to take action on a request and submit a complaint with the competent authority if your appeal is denied. 

## 9. Children

Our website is not designed to attract children and it is not our intent to collect personal data from children under the age of consent in their country of residence. We therefore request that children under the age of consent do not submit any personal data to us.

## 10. Contact details

RM Lingo
United States and Middle East
United States
Website: [https://rmlingo.com](https://rmlingo.com/) 
Email: info@ex.comrmlingo.com 
Toll free phone number: info@rmlingo.com
Phone number: \+972 595 555 0535

## RM Lingo Professional Language Services 
![Privacy Statement](https://rmlingo.com/wp-content/uploads/2025/01/Logo_vertical_white.png) 

##### Newsletter

#### Subscribe to our Newsletter

##### Join our community\! Subscribe to our newsletter and stay in the loop.
Leave this field empty if you're human: 

##### RM Lingo

RM Lingo was founded in 2003 by Dr. Rawan Manna, Ph.D., a highly skilled linguist and expert in translation and interpretation.

##### Recent news
-  [The Role of Professional Translation in Global Communication](https://rmlingo.com/the-role-of-professional-translation-in-global-communication/)  
-  [How to Choose the Right Provider for Your Subtitling and Dubbing Needs](https://rmlingo.com/how-to-choose-the-right-provider-for-your-subtitling-and-dubbing-needs/)  
-  [The Benefits of Real\-Time Interpretation Services for International Businesses](https://rmlingo.com/the-benefits-of-real-time-interpretation-services-for-international-businesses/)  

##### Services
- [Translation](https://rmlingo.com/translation-services/) 
- [Editing and proofreading](https://rmlingo.com/editing-and-proofreading/) 
- [Interpreting](https://rmlingo.com/interpreting/) 
- [Consultation and training](https://rmlingo.com/consultation/) 
- [Other services](https://rmlingo.com/other-services/) 
© 2026 RM Lingo • 

**  
[](https://rmlingo.com/privacy-statement-us/)
[↑](https://rmlingo.com/privacy-statement-us/)
Manage your privacy 
This site is registered on [wpml.org](https://wpml.org/) as a development site. Switch to a production site key to [remove this banner](https://wpml.org/faq/how-to-remove-the-this-site-is-registered-on-wpml-org-as-a-development-site-notice/?utm_source=plugin&utm_medium=gui&utm_campaign=wpml-core&utm_term=footer-notice).
