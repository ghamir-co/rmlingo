![RM Lingo](https://rmlingo.com/wp-content/uploads/2025/06/Rm_Lingo-1.png)
Manage your privacy
To provide the best experiences, we use technologies like cookies to store and/or access device information. Consenting to these technologies will allow us to process data such as browsing behavior or unique IDs on this site. Not consenting or withdrawing consent, may adversely affect certain features and functions.
Functional   [ ]  Functional  Always active       
The technical storage or access is strictly necessary for the legitimate purpose of enabling the use of a specific service explicitly requested by the subscriber or user, or for the sole purpose of carrying out the transmission of a communication over an electronic communications network. 
Preferences  [ ]  Preferences       
The technical storage or access is necessary for the legitimate purpose of storing preferences that are not requested by the subscriber or user. 
Statistics  [ ]  Statistics       
The technical storage or access that is used exclusively for statistical purposes. The technical storage or access that is used exclusively for anonymous statistical purposes. Without a subpoena, voluntary compliance on the part of your Internet Service Provider, or additional records from a third party, information stored or retrieved for this purpose alone cannot usually be used to identify you. 
Marketing  [ ]  Marketing       
The technical storage or access is required to create user profiles to send advertising, or to track the user on a website or across several websites for similar marketing purposes. 
[Manage options](https://rmlingo.com/opt-out-preferences/#cmplz-manage-consent-container)
[Manage services](https://rmlingo.com/opt-out-preferences/#cmplz-cookies-overview)
[Manage \{vendor\_count\} vendors](https://rmlingo.com/opt-out-preferences/#cmplz-tcf-wrapper)
[Read more about these purposes](https://cookiedatabase.org/tcf/purposes/)
Accept Deny View preferences Save preferences 
[View preferences](https://rmlingo.com/opt-out-preferences/#cmplz-manage-consent-container)
[Opt\-out preferences](https://rmlingo.com/opt-out-preferences/)
[Privacy Statement](https://rmlingo.com/privacy-statement-us/)
[\{title\}](https://rmlingo.com/contact/#)
[![RM Lingo](https://rmlingo.com/wp-content/uploads/2025/06/Rm_Lingo.png) ](https://rmlingo.com/)
[![RM Lingo](https://rmlingo.com/wp-content/uploads/2025/06/Rm_Lingo-1.png) ](https://rmlingo.com/)
- [**\+1 619\-752\-5604](https://wa.me/16197525604) 
- [**info@rmlingo.com](mailto:info@rmlingo.com) 
[ ]  **✕ Menu 
- [Home](https://rmlingo.com/) 
- [About Us](https://rmlingo.com/about/) 
- [Services](https://rmlingo.com/contact/#) 
  - [Interpreting](https://rmlingo.com/interpreting/) 
  - [Translation](https://rmlingo.com/translation-services/) 
  - [Editing and proofreading](https://rmlingo.com/editing-and-proofreading/) 
  - [Localization and relocation](https://rmlingo.com/localization-and-relocation/) 
  - [Media accessibility services](https://rmlingo.com/transcription-and-subtitling-dubbing-and-voiceover/) 
  - [Consulting services and training](https://rmlingo.com/consultation/) 
  - [Technical support and equipment](https://rmlingo.com/technical-support-and-equipment/) 
- [Testimonials](https://rmlingo.com/testimonials/) 
- [Contact Us **](https://rmlingo.com/contact/) 
- [English](https://rmlingo.com/contact/) 
[Home](https://rmlingo.com/) Contact Us 

# Contact Us

# To contact us directly by telephone or email:  


# 
#### Telephone/WhatsApp : 
International: [\+972 595 555 0535](tel:+972 595 555 0535) 
North America: \+1 240 602 2856 

#### Email : 
[tel:+1 240 602 2856](tel:+1 240 602 2856)
[info@rmlingo.com](mailto:info@rmlingo.com)



Your Name\*

Your Email\*

Phone Number\*

Subject 

Your Message 


## RM Lingo Professional Language Services 
![Contact Us](https://rmlingo.com/wp-content/uploads/2025/01/Logo_vertical_white.png) 

##### Newsletter

#### Subscribe to our Newsletter

##### Join our community\! Subscribe to our newsletter and stay in the loop.
Leave this field empty if you're human: 

##### RM Lingo

RM Lingo was founded in 2003 by Dr. Rawan Manna, Ph.D., a highly skilled linguist and expert in translation and interpretation.

##### Recent news
-  [The Role of Professional Translation in Global Communication](https://rmlingo.com/the-role-of-professional-translation-in-global-communication/)  
-  [How to Choose the Right Provider for Your Subtitling and Dubbing Needs](https://rmlingo.com/how-to-choose-the-right-provider-for-your-subtitling-and-dubbing-needs/)  
-  [The Benefits of Real\-Time Interpretation Services for International Businesses](https://rmlingo.com/the-benefits-of-real-time-interpretation-services-for-international-businesses/)  

##### Services
- [Translation](https://rmlingo.com/translation-services/) 
- [Editing and proofreading](https://rmlingo.com/editing-and-proofreading/) 
- [Interpreting](https://rmlingo.com/interpreting/) 
- [Consultation and training](https://rmlingo.com/consultation/) 
- [Other services](https://rmlingo.com/other-services/) 
© 2026 RM Lingo • 

**  
[](https://rmlingo.com/contact/)
[↑](https://rmlingo.com/contact/)
Manage your privacy 
This site is registered on [wpml.org](https://wpml.org/) as a development site. Switch to a production site key to [remove this banner](https://wpml.org/faq/how-to-remove-the-this-site-is-registered-on-wpml-org-as-a-development-site-notice/?utm_source=plugin&utm_medium=gui&utm_campaign=wpml-core&utm_term=footer-notice).
